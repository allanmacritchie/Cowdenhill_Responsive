#Aptana Twitter Bootstrap Bundle#

##Installation without Git##

### 1. Get the Bundle ###

The downloaded the repo as zip


### 2. Copy of Bundle ###

Go to USER_DIRECTORY/Documents/Aptana Rubles and create a folder "twitter-bootstrap.ruble" and extract the contents into that folder

Restart aptana to be sure everything is ok

##Installation with Git (RECOMMENDED)##

    mkdir -p ~/Documents/Aptana\ Rubles
    cd ~/Documents/Aptana\ Rubles
    git clone git://github.com/berkayunal/twitter-bootstrap.ruble.git
    

## Check the Install ##

Check Window -> Show View -> Other or the Commands menu to see if "Twitter Bootstrap Bundle" installed correctly

##How to use##

You can use the Commands > Twitter Bootstrap or you can start typing tb in the editor and the snippets will be shown with autocomplete.

All bundle elements starts with tb and you can see the triggers from the Commands > Twitter Bootstrap menu

For anyone who is interested in contributing please contact me from my homepage 

And for the ones who want to program their own rubles read below
https://aptanastudio.tenderapp.com/kb/scripting-aptana-studio/ruble-programming-guide

